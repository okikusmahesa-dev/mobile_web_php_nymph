<?
$gHtsIp   = "127.0.0.1";
//$hHtsIp	= $_SERVER['REMOTE_ADDR'];
$gHtsPort = "7011";
?>
