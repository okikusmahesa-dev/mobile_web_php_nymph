<div data-role="footer" data-position="fixed" data-theme="b" align="right">
	<input type="text" name="pesan">
	<a href="#" onclick="return goBuyExt()" data-role="button" data-icon="plus">Send</a>
</div>
